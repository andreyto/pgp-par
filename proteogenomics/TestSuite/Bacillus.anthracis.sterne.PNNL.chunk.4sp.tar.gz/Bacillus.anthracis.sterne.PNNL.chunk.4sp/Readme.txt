##This is a test dataset.

The real data directory has been modified in the
following ways, in order to drastically reduce
both the size and the run time of the test:

1. Chromosome was cut to a length below 500Kbp
2. Only 4 spectra files were selected

A directory DerivedData.expected has been
added. It contains DerivedData output
directory from a previous reference run.
