/*
Copyright (C) 2008- The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file COPYING for details.
*/

#ifndef URL_DECODE_H
#define URL_ENCODE_H


int b64_encode(const char *input, int len, char *output, int buf_len);


#endif
