#!/bin/bash

rm -f random.seq random_revcom.seq random.fa random.cfa random.cand filter.log filter.log.old worker.log
