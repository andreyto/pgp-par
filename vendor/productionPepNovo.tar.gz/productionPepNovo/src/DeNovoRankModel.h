#ifndef __DENOVORANKMODEL_H__
#define __DENOVORANKMODEL_H__



void select_denovo_samples();



#endif


